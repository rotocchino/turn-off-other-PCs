Per spegnere il pc delle altre persone devi aprere spengi, devi cliccare su aggiungi e devi aggiungere l'ip della vittima
-------------------------------------
code: 2022
-------------------------------------

se vuoi fare un test per spegnere il pc ti consiglio di usare il file (find.exe), non sono ip casuali ma sono ip o del tuo pc o
della tua connesione di casa.







                                                                            By rotocco

                      