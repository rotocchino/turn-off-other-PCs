To turn off other people's pc you have to open turn off, you have to click on add and you have to add the victim's IP
-------------------------------------
code: 2022
-------------------------------------

if you want to do a test to turn off the pc I suggest you use the file (find.exe), they are not random ip but they are ip or of your pc or
of your home connection.







                                                                             By rotocco